# Publish The Lost Kingdom (easy version)

You only need to do this once.

## Step 1 — Put the project on GitHub
1. Open https://github.com/new and sign in.
2. Create a repository named `lost-kingdom-coop`.
3. Choose **Add file → Upload files**.
4. Upload these items from this ZIP: `server.js`, `package.json`, `render.yaml`, and `README.md`, plus the `public` folder and its `index.html`.
   - Important: `index.html` must be inside a folder named `public`.
5. Tap **Commit changes**.

## Step 2 — Deploy on Render
1. Open https://render.com/ and sign in.
2. Choose **New + → Blueprint** (or Web Service if Blueprint is not offered).
3. Connect your `lost-kingdom-coop` GitHub repository.
4. If using Blueprint, Render reads `render.yaml` and fills in the settings. Approve/deploy.
5. If using Web Service, set Build Command to `npm install` and Start Command to `npm start`; choose a free instance if offered.
6. Wait until the service says Live, then open the `.onrender.com` URL.

## Step 3 — Play with your friend
1. Both players open the same Render URL.
2. One taps **Create room** and sends the 5-character code.
3. The other enters the code and taps **Join room**.

Notes: Render's free-plan availability and sleep limits can change. First load may take a little time. Room state is temporary and resets if the server restarts. Do not use private information in player names.
