const path = require("path");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, game: "The Lost Kingdom Co-op" }));

const rooms = new Map();
const MAP_W = 16, MAP_H = 10;
const START = [
  { id: "elder", type: "elder", x: 2, y: 2, used: false },
  { id: "chest", type: "chest", x: 4, y: 8, used: false },
  { id: "g1", type: "goblin", x: 12, y: 3, hp: 8, alive: true },
  { id: "g2", type: "goblin", x: 13, y: 4, hp: 8, alive: true },
  { id: "g3", type: "goblin", x: 14, y: 3, hp: 8, alive: true },
  { id: "shrine", type: "shrine", x: 14, y: 8, used: false }
];
function freshRoom(code) {
  return { code, players: {}, objects: structuredClone(START), gold: 0, potions: 2, questStarted: false, chestOpened: false, questComplete: false, createdAt: Date.now() };
}
function cleanRoom(room) {
  return { code: room.code, players: room.players, objects: room.objects, gold: room.gold, potions: room.potions,
    questStarted: room.questStarted, chestOpened: room.chestOpened, questComplete: room.questComplete };
}
function roomOf(socket) { return socket.data.roomCode && rooms.get(socket.data.roomCode); }
function broadcast(room) { io.to(room.code).emit("state", cleanRoom(room)); }
function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code;
  do { code = Array.from({length:5},()=>chars[Math.floor(Math.random()*chars.length)]).join(""); } while (rooms.has(code));
  return code;
}
function fail(socket, message) { socket.emit("notice", { message }); }
io.on("connection", socket => {
  socket.on("createRoom", ({name} = {}) => {
    const code = makeCode(), room = freshRoom(code);
    room.players[socket.id] = { id: socket.id, name: safeName(name, "Player 1"), hero: "Aric", x: 2, y: 3, hp: 18, maxHp: 18, online: true };
    rooms.set(code, room); socket.join(code); socket.data.roomCode = code;
    socket.emit("joined", { code, playerId: socket.id, hero: "Aric" }); broadcast(room);
  });
  socket.on("joinRoom", ({code, name} = {}) => {
    code = String(code || "").trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return fail(socket, "Room code not found. Ask your friend to create a room first.");
    if (Object.keys(room.players).length >= 2) return fail(socket, "This room already has two players.");
    if (room.players[socket.id]) return;
    room.players[socket.id] = { id: socket.id, name: safeName(name, "Player 2"), hero: "Lysa", x: 3, y: 3, hp: 14, maxHp: 14, online: true };
    socket.join(code); socket.data.roomCode = code;
    socket.emit("joined", { code, playerId: socket.id, hero: "Lysa" });
    io.to(code).emit("notice", { message: `${room.players[socket.id].name} joined the adventure!` }); broadcast(room);
  });
  socket.on("move", ({dx,dy} = {}) => {
    const room = roomOf(socket); if (!room || !room.players[socket.id]) return;
    dx = Math.max(-1, Math.min(1, Number(dx)||0)); dy = Math.max(-1, Math.min(1, Number(dy)||0));
    if (Math.abs(dx)+Math.abs(dy)!==1) return;
    const p = room.players[socket.id], nx=p.x+dx, ny=p.y+dy;
    if (nx<1||nx>=MAP_W-1||ny<1||ny>=MAP_H-1) return;
    // Keep the south river impassable except at the bridge.
    if (ny===8 && nx!==7 && nx!==8 && nx!==9) return;
    p.x=nx; p.y=ny;
    const goblin = room.objects.find(o=>o.type==="goblin"&&o.alive&&Math.abs(o.x-p.x)+Math.abs(o.y-p.y)<=1);
    if (goblin) socket.emit("notice",{message:"A goblin is close! Select it on the map or press Attack."});
    broadcast(room);
  });
  socket.on("interact", () => {
    const room=roomOf(socket); if(!room||!room.players[socket.id]) return;
    const p=room.players[socket.id];
    const obj=room.objects.find(o=>Math.abs(o.x-p.x)+Math.abs(o.y-p.y)<=1 && (o.type!=="goblin"||o.alive));
    if(!obj) return fail(socket,"Nothing nearby to interact with.");
    if(obj.type==="elder"){
      room.questStarted=true;
      io.to(room.code).emit("notice",{message:"The Elder asks you to defeat all three goblins and recover the relic. Head east!"});
    } else if(obj.type==="chest"){
      if(!room.questStarted) return fail(socket,"Talk to the Village Elder first.");
      if(room.objects.some(o=>o.type==="goblin"&&o.alive)) return fail(socket,"The chest is protected. Defeat all three goblins first.");
      if(!room.chestOpened){room.chestOpened=true;room.gold+=30;room.potions+=1;io.to(room.code).emit("notice",{message:"Treasure found! Shared party gains 30 gold and one healing potion."});}
      else fail(socket,"The chest is empty.");
    } else if(obj.type==="shrine"){
      if(!room.chestOpened) return fail(socket,"The shrine responds to the relic. Open the chest first.");
      room.questComplete=true;io.to(room.code).emit("notice",{message:"Quest complete! You recovered the Lost Kingdom relic. Return to the Elder to celebrate."});
    } else if(obj.type==="goblin") {
      fail(socket,"Goblin spotted! Select it and use Attack.");
    }
    broadcast(room);
  });
  socket.on("attack", ({targetId, skill} = {}) => {
    const room=roomOf(socket); if(!room||!room.players[socket.id]) return;
    const p=room.players[socket.id];
    const target=room.objects.find(o=>o.id===targetId&&o.type==="goblin"&&o.alive);
    if(!target) return fail(socket,"Choose a living goblin on the map first.");
    if(Math.abs(target.x-p.x)+Math.abs(target.y-p.y)>3) return fail(socket,"Move closer to attack (within 3 tiles).");
    const dmg=skill?7:(p.hero==="Aric"?5:4)+Math.floor(Math.random()*3);
    target.hp-=dmg;
    io.to(room.code).emit("notice",{message:`${p.name} hits a goblin for ${dmg} damage.`});
    if(target.hp<=0){target.alive=false;room.gold+=5;io.to(room.code).emit("notice",{message:"Goblin defeated! The party gains 5 gold."});}
    // Simple shared enemy response to keep combat lively.
    if(target.alive){
      const living=Object.values(room.players).filter(q=>q.hp>0);
      if(living.length){const victim=living[Math.floor(Math.random()*living.length)];victim.hp=Math.max(0,victim.hp-(Math.random()<.25?1:2));io.to(room.code).emit("notice",{message:`A goblin counterattacks! ${victim.name} loses some HP.`});}
    }
    broadcast(room);
  });
  socket.on("usePotion", () => {
    const room=roomOf(socket); if(!room||!room.players[socket.id]) return;
    if(room.potions<=0) return fail(socket,"No shared potions left.");
    const injured=Object.values(room.players).filter(p=>p.hp>0&&p.hp<p.maxHp);
    if(!injured.length) return fail(socket,"Everyone is already at full health.");
    room.potions--;
    for(const p of injured) p.hp=Math.min(p.maxHp,p.hp+6);
    io.to(room.code).emit("notice",{message:"The party used a potion. Injured heroes recover up to 6 HP."});broadcast(room);
  });
  socket.on("rest", () => {
    const room=roomOf(socket);if(!room||!room.players[socket.id])return;
    for(const p of Object.values(room.players)) p.hp=p.maxHp;
    io.to(room.code).emit("notice",{message:"The party rests at Stonebrook. Everyone is fully healed."});broadcast(room);
  });
  socket.on("disconnect", () => {
    const room=roomOf(socket);if(!room)return;
    if(room.players[socket.id]) { room.players[socket.id].online=false; io.to(room.code).emit("notice",{message:`${room.players[socket.id].name} disconnected.`}); }
    // Keep rooms alive for a while so brief mobile disconnects don't erase a session.
    setTimeout(()=>{const r=rooms.get(room.code);if(r&&Object.values(r.players).every(p=>!p.online)){rooms.delete(room.code);}},30*60*1000);
    broadcast(room);
  });
});
function safeName(name, fallback) { return String(name||fallback).trim().slice(0,18)||fallback; }
const port = process.env.PORT || 3000;
server.listen(port, "0.0.0.0", () => console.log(`The Lost Kingdom running on ${port}`));
