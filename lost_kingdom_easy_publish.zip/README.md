# The Lost Kingdom — Online Co-op

A small real-time, two-player browser RPG. The server synchronizes player movement, enemy health, shared gold, potions, and quest progress.

## Run locally
1. Install Node.js 18 or newer from https://nodejs.org/
2. Extract this folder.
3. In this folder run:
   ```sh
   npm install
   npm start
   ```
4. Open http://localhost:3000 in your browser. To test two players on one computer, open a second browser/incognito window and join the room code.

## Publish free with Render
1. Create a GitHub account at https://github.com/ and make a new repository.
2. Upload `server.js`, `package.json`, `README.md`, and the `public` folder (with `index.html`) to the repository.
3. Go to https://render.com/ and sign in.
4. Choose **New → Web Service**, connect your repository.
5. Set **Build Command** to `npm install` and **Start Command** to `npm start`. Choose the free instance if available.
6. Deploy, then open the `https://....onrender.com` URL.
7. Both you and your friend open that same URL. One taps **Create room** and sends the five-character code to the other. The other enters it and taps **Join room**.

Notes:
- Free hosting availability and sleep/usage limits can change. A sleeping free service may take a short while to wake.
- Room state is held in server memory, so it resets if the server restarts or redeploys.
- This is a friendly prototype, not a secured public commercial game. Do not put private information in player names.
- Use a modern browser. Socket.IO uses a persistent connection for live updates.
